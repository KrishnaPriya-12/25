import { Planter } from './planter';

describe('Planter', () => {
  it('should create an instance', () => {
    expect(new Planter()).toBeTruthy();
  });
});
