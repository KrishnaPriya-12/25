import { OrderDTO } from './order-dto';

describe('OrderDTO', () => {
  it('should create an instance', () => {
    expect(new OrderDTO()).toBeTruthy();
  });
});
